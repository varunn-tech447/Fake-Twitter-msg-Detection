import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface AnalysisResult {
  isFake: "YES" | "NO" | "Possibly Fake";
  explanation: string;
  confidence: number;
  indicators: string[];
}

export async function analyzeNews(text: string): Promise<AnalysisResult> {
  if (!text.trim()) {
    throw new Error("No news text provided");
  }

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following news text for potential misinformation or "Fake News" characteristics.
    
Rules:
- Look for sensational language, lack of specific sources, exaggerated claims, and emotional manipulation.
- Do not guess facts if unsure about the specific event.
- Evaluate the LIKELIHOOD of it being fake based on textual indicators.

News Text:
${text}`,
    config: {
      systemInstruction: `You are a professional fact-checker and media literacy expert. 
      Your task is to analyze news text and identify if it shows signs of being fake news.
      Focus on structure, tone, and logical consistency rather than real-time fact-checking if the events are obscure.
      Always provide the result in JSON format.`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          isFake: {
            type: Type.STRING,
            enum: ["YES", "NO", "Possibly Fake"],
            description: "Strictly YES, NO, or Possibly Fake",
          },
          explanation: {
            type: Type.STRING,
            description: "A short 2-3 line explanation of the verdict.",
          },
          confidence: {
            type: Type.NUMBER,
            description: "A confidence score from 0 to 1.",
          },
          indicators: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of specific red flags or positive indicators found.",
          }
        },
        required: ["isFake", "explanation", "confidence", "indicators"],
      },
    },
  });

  return JSON.parse(response.text);
}
