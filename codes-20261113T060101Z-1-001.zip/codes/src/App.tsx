import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, CheckCircle, HelpCircle, Search, Terminal, Info, ShieldAlert, Newspaper, Cpu } from 'lucide-react';
import { analyzeNews, type AnalysisResult } from './services/gemini';

export default function App() {
  const [inputText, setInputText] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!inputText.trim()) return;
    
    setLoading(true);
    setError(null);
    setResult(null);
    
    try {
      const data = await analyzeNews(inputText);
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred during analysis.');
    } finally {
      setLoading(false);
    }
  };

  const getVerdictDetails = (isFake: string) => {
    switch (isFake) {
      case 'YES':
        return {
          icon: <ShieldAlert className="w-10 h-10 text-rose-500" />,
          color: 'text-rose-600',
          bgColor: 'bg-rose-50',
          borderColor: 'border-rose-200',
          badgeBg: 'bg-rose-600',
          indicatorColor: 'bg-rose-500',
          label: 'FAKE NEWS'
        };
      case 'NO':
        return {
          icon: <CheckCircle className="w-10 h-10 text-emerald-500" />,
          color: 'text-emerald-600',
          bgColor: 'bg-emerald-50',
          borderColor: 'border-emerald-200',
          badgeBg: 'bg-emerald-600',
          indicatorColor: 'bg-emerald-500',
          label: 'LIKELY AUTHENTIC'
        };
      default:
        return {
          icon: <HelpCircle className="w-10 h-10 text-amber-500" />,
          color: 'text-amber-600',
          bgColor: 'bg-amber-50',
          borderColor: 'border-amber-200',
          badgeBg: 'bg-amber-600',
          indicatorColor: 'bg-amber-500',
          label: 'POSSIBLY FAKE'
        };
    }
  };

  return (
    <div className="min-h-screen p-6 md:p-8 flex flex-col font-sans">
      <header className="max-w-7xl w-full mx-auto flex justify-between items-center mb-8 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">V</div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-800">Veritas AI</h1>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-none">Heuristic Verification Engine</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-green-100 text-green-700 rounded-full text-[10px] font-bold uppercase tracking-wider">
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
            System Active
          </div>
          {result && (
             <button 
              onClick={() => { setResult(null); setInputText(''); }}
              className="px-4 py-2 bg-slate-800 text-white rounded-lg text-xs font-bold uppercase tracking-wider hover:bg-slate-700 transition-colors"
             >
               New Analysis
             </button>
          )}
        </div>
      </header>

      <main className="max-w-7xl w-full mx-auto flex-1 flex flex-col">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 auto-rows-min">
          
          {/* Main Content Area: Input or Display */}
          <section className={`${result ? 'md:col-span-8' : 'md:col-span-12'} bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col transition-all duration-500 min-h-[400px]`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Input Analysis Buffer</h2>
              {result && <span className="text-[10px] text-zinc-400 font-mono">HASH: 882-VX-{result.confidence.toString().slice(2, 4)}</span>}
            </div>
            
            <div className="flex-1 flex flex-col">
              {result ? (
                <div className="flex-1 flex flex-col">
                  <p className="text-xl leading-relaxed text-slate-700 italic flex-1">
                    "{inputText}"
                  </p>
                  <div className="mt-8 flex flex-col sm:flex-row gap-4">
                    <div className="flex-1 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter mb-2">Computational Metadata</p>
                      <div className="space-y-1">
                        <p className="text-xs text-slate-600 flex justify-between"><span>Entropy:</span> <span className="font-mono">{(inputText.length * 0.12).toFixed(2)}</span></p>
                        <p className="text-xs text-slate-600 flex justify-between"><span>Token Density:</span> <span className="font-mono">{(inputText.trim().split(/\s+/).length / inputText.length).toFixed(3)}</span></p>
                      </div>
                    </div>
                    <div className="flex-1 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter mb-2">Linguistic Style</p>
                      <div className="space-y-1">
                        <p className="text-xs text-slate-600 flex justify-between"><span>Type:</span> <span className="font-semibold">{result.indicators[0] || 'Unclassified'}</span></p>
                        <p className="text-xs text-slate-600 flex justify-between"><span>Tones:</span> <span className="font-semibold">{result.isFake === 'YES' ? 'Aggressive' : 'Informative'}</span></p>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col">
                  <textarea
                    id="news_input"
                    className="flex-1 w-full bg-transparent border-none focus:ring-0 text-slate-700 placeholder:text-slate-300 resize-none font-sans text-xl leading-relaxed outline-none"
                    placeholder="Paste report or news excerpt here to initiate verification protocols..."
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                  />
                  <div className="mt-6 flex justify-between items-center bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <div className="flex gap-6 font-mono text-[10px] text-slate-400 uppercase font-bold">
                      <span>Chars: {inputText.length}</span>
                      <span>Words: {inputText.trim() ? inputText.trim().split(/\s+/).length : 0}</span>
                    </div>
                    <button
                      id="analyze_button"
                      onClick={handleAnalyze}
                      disabled={loading || !inputText.trim()}
                      className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-indigo-700 disabled:opacity-30 disabled:cursor-not-allowed shadow-lg shadow-indigo-600/20 transition-all active:scale-95 flex items-center gap-2"
                    >
                      {loading ? <Search className="w-4 h-4 animate-spin" /> : <Cpu className="w-4 h-4" />}
                      {loading ? 'Processing...' : 'Execute Analysis'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* Result Cards appearing on analysis */}
          <AnimatePresence mode="wait">
            {result && (
              <>
                {/* Result Block 2: Verdict (Right Side) */}
                <motion.section 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`${result.isFake === 'YES' ? 'bg-rose-50 border-rose-200' : result.isFake === 'NO' ? 'bg-emerald-50 border-emerald-200' : 'bg-amber-50 border-amber-200'} md:col-span-4 rounded-3xl p-8 border flex flex-col items-center justify-center text-center shadow-sm`}
                >
                  {(() => {
                    const details = getVerdictDetails(result.isFake);
                    return (
                      <>
                        <h2 className={`text-xs font-black uppercase tracking-widest mb-4 opacity-60 text-slate-900`}>Verdict</h2>
                        <div className={`text-7xl font-black mb-4 ${details.color}`}>{result.isFake}</div>
                        <div className={`px-5 py-1.5 ${details.badgeBg} text-white rounded-full text-[10px] font-black uppercase tracking-widest mb-6`}>
                          {details.label}
                        </div>
                        <p className={`text-[11px] font-medium leading-relaxed opacity-60 text-slate-900`}>Linguistic markers indicate a strong alignment with identified disinformation patterns.</p>
                      </>
                    )
                  })()}
                </motion.section>

                {/* Result Block 3: AI Explanation (Left Bottom) */}
                <motion.section 
                   initial={{ opacity: 0, y: 20 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ delay: 0.1 }}
                   className="md:col-span-6 bg-white border border-slate-200 rounded-3xl p-7 shadow-sm"
                >
                  <h2 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Logical Decomposition</h2>
                  <p className="text-sm text-slate-600 leading-relaxed font-medium">
                    {result.explanation}
                  </p>
                </motion.section>

                {/* Result Block 4: Confidence Score (Right Bottom 1) */}
                <motion.section 
                   initial={{ opacity: 0, y: 20 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ delay: 0.2 }}
                   className="md:col-span-3 bg-slate-800 rounded-3xl p-7 flex flex-col justify-between text-white"
                >
                  <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Credibility Score</h3>
                  <div className="my-4">
                    <div className="flex items-end gap-2 mb-2">
                       <span className="text-5xl font-black">{((1 - (result.isFake === 'YES' ? 0.8 : result.isFake === 'NO' ? 0.1 : 0.4)) * 100).toFixed(0)}%</span>
                       <span className="text-[10px] text-slate-400 font-bold uppercase mb-2">Trust</span>
                    </div>
                    <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                       <div className={`h-full transition-all duration-1000 ${result.isFake === 'NO' ? 'bg-emerald-500 w-[90%]' : result.isFake === 'YES' ? 'bg-rose-500 w-[20%]' : 'bg-amber-500 w-[60%]'}`}></div>
                    </div>
                  </div>
                  <p className="text-[9px] font-bold text-slate-500 uppercase tracking-tight">Algorithmic confidence based on data sample</p>
                </motion.section>

                {/* Result Block 5: Indicators (Right Bottom 2) */}
                <motion.section 
                   initial={{ opacity: 0, y: 20 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ delay: 0.3 }}
                   className="md:col-span-3 bg-white border border-slate-200 rounded-3xl p-7 shadow-sm"
                >
                   <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-5 italic">Red Flags Detected</h3>
                   <div className="flex flex-wrap gap-2">
                      {result.indicators.slice(0, 4).map((tag, i) => (
                        <span key={i} className="px-2.5 py-1.5 bg-slate-50 text-[10px] font-bold text-indigo-600 rounded-lg border border-indigo-100 uppercase">
                          {tag}
                        </span>
                      ))}
                   </div>
                </motion.section>
              </>
            )}
          </AnimatePresence>

          {/* Loading State Overlay or Block */}
          {loading && !result && (
             <div className="md:col-span-12 flex items-center justify-center p-20">
                <div className="flex flex-col items-center">
                   <div className="relative w-20 h-20 mb-6">
                      <div className="absolute inset-0 border-4 border-slate-200 rounded-full"></div>
                      <div className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
                      <Cpu className="absolute inset-0 m-auto w-8 h-8 text-indigo-600" />
                   </div>
                   <p className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] animate-pulse">Running Forensic Linguistic Analysis...</p>
                </div>
             </div>
          )}

          {error && (
            <div className="md:col-span-12 bg-rose-50 border border-rose-200 rounded-3xl p-6 text-rose-600 flex items-center gap-4">
              <AlertTriangle className="w-6 h-6" />
              <p className="text-sm font-bold uppercase tracking-wide">{error}</p>
            </div>
          )}

        </div>
      </main>

      <footer className="max-w-7xl w-full mx-auto mt-12 flex flex-col md:flex-row justify-between items-center text-[10px] font-bold text-slate-400 border-t border-slate-100 pt-6 gap-4">
        <div className="flex flex-wrap justify-center gap-6 uppercase tracking-widest">
          <span className="flex items-center gap-1.5"><Cpu className="w-3 h-3" /> System: Gemini 3 Flash</span>
          <span>Security: Vertex AI Shield</span>
          <span className="text-indigo-600">Pro v2.4.0</span>
        </div>
        <div className="uppercase tracking-widest">© 2026 Veritas AI • Heuristic News Verification</div>
      </footer>
    </div>
  );
}
